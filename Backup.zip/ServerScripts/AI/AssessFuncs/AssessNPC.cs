﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Server.Scripts.AI.AssessFuncs
{
    class AssessNPC
    {
    }
}

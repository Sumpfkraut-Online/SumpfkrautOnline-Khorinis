﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GUC.Server.Scripting.Objects.Character;

namespace GUC.Server.Scripts.AI.Routines
{
    public static class Routine
    {
        public delegate void OnRoutine(NPCProto proto);

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Server.Scripts.AI.Enumeration
{
    public enum GuildsAttitude
    {
        HOSTILE,
        NEUTRAL,
        FRIENDLY
    }
}

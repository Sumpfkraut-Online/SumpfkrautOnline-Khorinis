﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.WorldObjects.Mobs
{
    internal partial class MobBed : MobInter
    {
        public MobBed()
            : base()
        {
            this.VobType = Enumeration.VobType.MobBed;
        }
    }
}

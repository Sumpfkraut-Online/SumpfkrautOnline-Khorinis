﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Options
{
    class Constants
    {
        public const String VERSION = "ver2.082";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Server.Network.Messages.MobInterCommands
{
    class ContainerMessage : IMessage
    {

        public void Read(RakNet.BitStream stream, RakNet.Packet packet, Server server)
        {
            
        }
    }
}

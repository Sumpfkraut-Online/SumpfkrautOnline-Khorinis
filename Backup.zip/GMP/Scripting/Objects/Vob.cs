﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Scripting.Objects
{
    public class Vob
    {
        internal WorldObjects.Vob iVob;

        internal Vob(WorldObjects.Vob _vob)
        {
            iVob = _vob;
        }
    }
}

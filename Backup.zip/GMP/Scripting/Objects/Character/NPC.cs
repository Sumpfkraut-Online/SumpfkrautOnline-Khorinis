﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GUC.Scripting.Objects.Character
{
    public class NPC : NPCProto
    {
        internal NPC(WorldObjects.Character.NPC ivob)
            : base(ivob)
        {

        }

    }
}
